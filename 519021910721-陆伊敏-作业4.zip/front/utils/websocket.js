/*
export const ws = new WebSocket("ws://localhost:8080/websocketbot");
ws.onopen = function (e) {
    console.log("已经连接上websocket服务器");
}
ws.onmessage*/
