import {postRequest} from "../utils/ajax";

export const visitHomePage = (callback) => {
    const url = `http://localhost:8080/visitHomePage`;
    postRequest(url, {}, callback);
};