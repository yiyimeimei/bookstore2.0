package com.reins.bookstore.websocket.messages;

public class Message {
}
