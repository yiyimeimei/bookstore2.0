package com.reins.bookstore.serviceimpl; 

import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 

/** 
* VisitServiceImpl Tester. 
* 
* @author <Authors name> 
* @since <pre>10�� 9, 2021</pre> 
* @version 1.0 
*/ 
public class VisitServiceImplTest { 

@Before
public void before() throws Exception { 
} 

@After
public void after() throws Exception { 
} 

/** 
* 
* Method: visitHomePage() 
* 
*/ 
@Test
public void testVisitHomePage() throws Exception { 
//TODO: Test goes here... 
} 


} 
