package com.reins.bookstore.dao;

public interface VisitDao {
    Integer visitHomePage();
}
