package com.reins.bookstore.service;

public interface VisitService
{
    Integer visitHomePage();
}
